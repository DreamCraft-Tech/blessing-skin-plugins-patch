<?php

namespace Blessing\FastLogin\Listeners;

use Illuminate\Support\Facades\DB;
use Ramsey\Uuid\Uuid;

class InsertToFastLogin
{
    public function handle($user, $profile)
    {
        $uuid = Uuid::fromString(data_get($profile, 'id'));

        DB::connection('fast-login')
            ->table('premium')
            ->insert([
                'UUID' => $uuid->toString(),
                'Name' => data_get($profile, 'name'),
                'Premium' => true,
                'LastIp' => '0.0.0.0',
            ]);
    }
}
