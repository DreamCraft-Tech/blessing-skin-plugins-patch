globalThis.blessing.event.on("beforeFetch",e=>{let a=new URLSearchParams(location.search);e.data.share=a.get("share")||""});
