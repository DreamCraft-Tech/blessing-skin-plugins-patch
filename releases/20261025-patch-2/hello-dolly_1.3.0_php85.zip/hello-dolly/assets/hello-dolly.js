{let l=`Hello, Dolly
Well, hello, Dolly
It's so nice to have you back where you belong
You're lookin' swell, Dolly
I can tell, Dolly
You're still glowin', you're still crowin'
You're still goin' strong
We feel the room swayin'
While the band's playin'
One of your old favourite songs from way back when
So, take her wrap, fellas
Find her an empty lap, fellas
Dolly'll never go away again
Hello, Dolly
Well, hello, Dolly
It's so nice to have you back where you belong
You're lookin' swell, Dolly
I can tell, Dolly
You're still glowin', you're still crowin'
You're still goin' strong
We feel the room swayin'
While the band's playin'
One of your old favourite songs from way back when
Golly, gee, fellas
Find her a vacant knee, fellas
Dolly'll never go away
Dolly'll never go away
Dolly'll never go away again`.split("\n"),e=l.length,o=document.createElement("div");o.style.marginTop="3px",o.textContent=l[Math.floor(Math.random()*e)];let n=document.querySelector(".breadcrumb");if(n)n.appendChild(o);else{let l=document.createElement("div");l.className="breadcrumb",l.appendChild(o),document.querySelector(".content-header")?.appendChild(l)}}
